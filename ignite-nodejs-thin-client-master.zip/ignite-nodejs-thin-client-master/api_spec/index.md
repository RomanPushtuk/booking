# Node.js Client for Apache Ignite

This is lightweight Ignite client which allows your Node.js applications to work with Ignite clusters via TCP.

For more information, see [Apache Ignite Node.js Thin Client documentation](https://ignite.apache.org/docs/latest/thin-clients/nodejs-thin-client).